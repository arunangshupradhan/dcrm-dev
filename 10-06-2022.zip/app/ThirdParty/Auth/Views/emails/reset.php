<p>A password update was requested on <?= site_url() ?>!</p>

<p>Please click the following link to change your password!</p>
<p><a href="<?= $hash_url ?>"><?= $hash_url ?></a></p>
<p>Link is valid for 30 minutes.</p>

<p>If you didn't request this change, just ignore this email.</p>