<div class="vertical-menu">
    <div data-simplebar class="h-100">
        <div id="sidebar-menu">
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title" key="t-menu">Menu</li>
                <li>
                    <a href="<?= site_url('service-providers/dashboard') ?>" class="waves-effect">
                       <i class="bx bx-home-circle font-size-15"></i>
                       <span key="t-dashboard" class="font-size-15">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow">
                        <i class="fas fa-users font-size-15"></i>
                        <span key="t-client" class="font-size-15">Clients</span>
                    </a>
                    <ul class="sub-menu mm-collapse" aria-expanded="false">
                       <li><a href="<?= site_url('service-providers/clients') ?>" key="t-client" class="font-size-14">Clients</a></li>
                       <li><a href="<?= site_url('service-providers/add-client') ?>" key="t-client" class="font-size-14">Add Client</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow">
                        <i class="dripicons-gear font-size-15"></i>
                        <span key="t-plan" class="font-size-15">Sttings</span>
                    </a>
                    <ul class="sub-menu mm-collapse" aria-expanded="false">
                       <li><a href="<?= site_url('service-providers/packages') ?>" key="t-plan" class="font-size-14">Our Plan List</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>