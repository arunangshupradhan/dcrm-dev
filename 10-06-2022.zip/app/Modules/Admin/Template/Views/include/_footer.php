<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<script>document.write(new Date().getFullYear())</script> © Docker.
			</div>
			<div class="col-sm-6">
				<div class="text-sm-end d-none d-sm-block">
					Design & Develop by Scriptlab
				</div>
			</div>
		</div>
	</div>
</footer>
</div>
</div>
</body>
</html>
